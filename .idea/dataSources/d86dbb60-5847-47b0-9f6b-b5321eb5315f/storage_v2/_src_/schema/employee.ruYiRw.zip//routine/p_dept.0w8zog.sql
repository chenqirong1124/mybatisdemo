create
  definer = root@localhost procedure p_dept(IN vdeptno int, OUT vdname varchar(20), OUT vloc varchar(20))
BEGIN
  select dname,loc into vdname,vloc from dept where deptno=vdeptno;
END;

