create
  definer = root@localhost procedure swap(INOUT v1 int, INOUT v2 int)
BEGIN
 DECLARE tmp int;
 set tmp =v1;
 set v1= v2;
 set v2= tmp;
end;

