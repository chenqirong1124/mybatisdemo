create
  definer = root@localhost procedure p_emp()
BEGIN
	DECLARE vdname VARCHAR(20);
  select dname into vdname from dept where depno=vdeptno;
  SELECT vdname;

END;

